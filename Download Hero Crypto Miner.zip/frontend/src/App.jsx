import React, { useState } from 'react';
import './App.css';
import axios from 'axios';

function App() {
  const [address, setAddress] = useState('');
  const [token, setToken] = useState('ETH');
  const [days, setDays] = useState(7);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [verdict, setVerdict] = useState('');

  const scanWallet = async () => {
    setLoading(true);
    setResults([]);
    setVerdict('');

    try {
      const res = await axios.get(`http://localhost:8000/api/detect`, {
        params: { address, token, days }
      });

      if (res.data.status === 'ok') {
        setResults(res.data.transactions);
        setVerdict(res.data.transactions.length === 0 ? '❌ No matching transactions found.' : '✅ Transactions found.');
      } else {
        setVerdict(`⚠️ ${res.data.message}`);
      }
    } catch (err) {
      setVerdict('❌ Error connecting to scanner.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <h1>Hero Crypto Miner</h1>
      <p>Find lost or failed Ethereum transactions</p>

      <input
        type="text"
        placeholder="Wallet Address (0x...)"
        value={address}
        onChange={(e) => setAddress(e.target.value)}
      />

      <input
        type="text"
        value={token}
        onChange={(e) => setToken(e.target.value)}
        placeholder="Token (e.g. ETH)"
      />

      <input
        type="number"
        value={days}
        onChange={(e) => setDays(e.target.value)}
        placeholder="Days to look back"
      />

      <button onClick={scanWallet} disabled={loading}>
        {loading ? 'Scanning...' : 'Scan Wallet'}
      </button>

      {verdict && <div className="verdict">{verdict}</div>}

      {results.length > 0 && (
        <table>
          <thead>
            <tr>
              <th>TX Hash</th>
              <th>From</th>
              <th>To</th>
              <th>Value</th>
              <th>Status</th>
              <th>Timestamp</th>
            </tr>
          </thead>
          <tbody>
            {results.map((tx, i) => (
              <tr key={i}>
                <td><a href={`https://etherscan.io/tx/${tx.hash}`} target="_blank" rel="noreferrer">{tx.hash.slice(0, 10)}...</a></td>
                <td>{tx.from.slice(0, 10)}...</td>
                <td>{tx.to?.slice(0, 10) || '—'}...</td>
                <td>{tx.value} ETH</td>
                <td>{tx.status}</td>
                <td>{new Date(tx.timestamp).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default App;