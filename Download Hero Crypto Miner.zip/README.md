# Hero Crypto Miner

A web app for recovering or tracing lost or failed Ethereum transactions.

## Features
- Search wallet address for transactions
- Show transaction status and details
- Categorize recoverability

## Setup
1. `cd backend`
2. `pip install -r requirements.txt`
3. `uvicorn main:app --reload`

4. `cd frontend`
5. `npm install`
6. `npm run dev`

Connect to: `http://localhost:8000/api/detect`